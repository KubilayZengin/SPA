import styled, { keyframes } from 'styled-components';
import { colors } from '../style/theme';

const Wrapper = styled.div`
  width: 100%;
  height: 66vh;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 18px;
`;

const Content = styled.h1`
  width: 100%;
  max-width: 600px;
  font-size: 64px;
  font-weight: 900;
  color: ${colors.content.primary};
  margin: 0;
  padding: 0;

  @media (max-width: 700px) {
    max-width: 100%;
    padding: 0 18px;
    font-size: 48px;
  }
`;

const Subtitle = styled.h2`
  width: 100%;
  max-width: 600px;
  font-size: 17px;
  color: ${colors.content.secondary};
  font-weight: normal;
  font-style: italic;
  margin: 0;
  padding: 0;
  @media (max-width: 700px) {
    max-width: 100%;
    padding: 0 18px;
  }
`;

const Header = ({
  title,
  description,
}: {
  title: string;
  description: string,
}) => {
  return <Wrapper>
    <Content>{title}</Content>
    <Subtitle>{description}</Subtitle>
  </Wrapper>;
};
export default Header;
