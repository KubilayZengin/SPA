import styled, { keyframes } from 'styled-components';
import { Palette } from '@vibrant/color';
import { getShade } from '../helpers/formatChart';
import { motion } from 'framer-motion';
import { colors } from '../style/theme';

const Container = styled(motion.div)`
  width: 100%;
  max-width: 620px;
  margin: 0 auto;
  margin-bottom: 128px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 64px;

  @media (max-width: 700px) {
    padding: 20px;
    gap: 48px;
    margin: 48px 0;
    margin-bottom: 0;
  }
`;

const Summary = styled(motion.div)`
  background-color: ${colors.surface.layer};
  color: ${colors.content.primary};
  border-radius: 20px;
  padding: 20px 22px;
  padding-left: 1.5rem;
  text-align: left;
  font-size: 15px;
  line-height: 1.5;
  position: relative;
  margin-bottom: 0.75rem;

  ol {
    list-style: none;
    counter-reset: item; /* Reset the counter */
    padding: 0;
    margin: 0;
    margin-top: -18px;

    li {
      counter-increment: item; /* Increment the counter */
      position: relative;
      padding-left: 96px; /* space for the ordinal */
      margin-block: 32px;

      &::before {
        content: '#' counter(item);
        position: absolute;
        left: 0;
        top: 0;
        width: 76px;
        text-align: center;
        font-size: 42px;
        font-weight: 700;
        color: ${colors.content.secondary};
        opacity: 0.4;
        line-height: 1;
      }
    }
  }
`;

const SummaryHeader = styled.div`
  user-select: none;
  width: 100%;
  display: flex;
  align-items: center;
  font-size: 15px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: ${colors.content.secondary};
`;

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.5,
      delayChildren: 0.3 + 0.25,
    },
  },
};

const childVariants = {
  hidden: { opacity: 0, y: 40 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
};

const Intro = ({
  summary,
}: {
  summary: string[];
}) => {
  return (
    <Container variants={containerVariants} initial="hidden" animate="show">
      <Summary variants={childVariants}>
        <SummaryHeader>
          {`Today's Top Ten`}
        </SummaryHeader>
        <ol>
          {summary.map((item, i) => (
            <li key={i}>
              {item}
            </li>
          ))}
        </ol>
      </Summary>
    </Container>
  );
};

export default Intro;
