import { Source } from "../components/Sources";

const optimizeImage = (imageUrl: string, width?: number): string => {
  try {
    let resolvedUrl = imageUrl;

    const url = new URL(imageUrl);
    if (url.hostname === 'images.mindstudio-cdn.com') {
      resolvedUrl = `${url.origin}${url.pathname}?fm=auto`;
    }

    if (width) {
      resolvedUrl += `&w=${width * 3}`;
    }

    return resolvedUrl;
  } catch {
    //
  }
  return imageUrl;
}


export type TocEntry = {
  id: string;
  text: string;
  children?: TocEntry[];
};

export const preprocessHtml = (html: string, charts: any[], sources: Source[]): { html: string; toc: TocEntry[] } => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const toc: TocEntry[] = [];

  // Fix links to open in a new tab
  doc.querySelectorAll('a').forEach((a) => {
    if (!a.hasAttribute('target')) {
      a.setAttribute('target', '_blank');
    }
  });

  // Optimize images
  const seenImgSrcs = new Set<string>();
  doc.querySelectorAll('img').forEach((img) => {
    const src = img.getAttribute('src');

    // Remove any image that are not wrapped in figures
    const isInFigure = img.parentElement?.tagName === 'FIGURE';
    if (!isInFigure) {
      img.remove();
      return;
    }

    // Remove any images we have already used
    if (!src || seenImgSrcs.has(src)) {
      img.parentElement?.remove();
      return;
    }

    seenImgSrcs.add(src);

    const isInAside = img.parentElement?.parentElement?.tagName === 'ASIDE';
    img.setAttribute('src', optimizeImage(src, isInAside ? 300 : undefined));

    img.setAttribute(
      'onerror',
      "this.parentElement && (this.parentElement.style.display = 'none')"
    );
  });

  // Remove duplicate IDs
  const seenIds = new Set<string>();
  doc.querySelectorAll<HTMLElement>('[id]').forEach((el) => {
    const id = el.getAttribute('id');
    if (!id) return;

    if (seenIds.has(id)) {
      el.parentElement?.remove();
    } else {
      seenIds.add(id);
    }
  });

  // Generate ToC from h2 and h3
  doc.querySelectorAll('h2, h3').forEach((heading) => {
    const text = heading.textContent?.trim() || '';
    const id = text
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^\w-]+/g, '');

    heading.setAttribute('id', id);

    if (heading.tagName === 'H2') {
      toc.push({
        id,
        text,
        children: [],
      });
    } else {
      try {
        toc[toc.length - 1].children!.push({
          id,
          text,
        });
      } catch {
        // fallback silently
      }
    }
  });

  // Add captions to any charts that are missing them.
  doc.querySelectorAll('canvas').forEach((el) => {
    try {
      const id = el.getAttribute('id');
      if (!id) return;

      // Get the matching chart
      const matchingChart = charts.find((chart) => chart.id === id);
      if (!matchingChart) {
        el.remove();
        return;
      }

      if (el.nextElementSibling?.tagName !== 'FIGCAPTION') {
        const { name } = matchingChart;
        const caption = document.createElement('figcaption');
        caption.innerText = name;
        el.parentElement?.appendChild(caption);
      }
    } catch (err) {
      //
    }
  });

  // Add eyebrows to section descriptions
  doc.querySelectorAll('.section-description').forEach((el) => {
    el.innerHTML = `<div class="eyebrow">Key Points</div><p>${el.innerHTML}</p>`;
  });

  // Resolve <sup> IDs to sources
  doc.querySelectorAll('sup').forEach((el) => {
    const text = el.textContent?.trim() || '';
    if (!text) {
      el.remove();
      return;
    }

    try {
      // Insert a non-breaking space before the <sup> element to prevent orphans
      const nbsp = document.createTextNode('\u00A0');
      el.parentNode?.insertBefore(nbsp, el);

      // Resolve the citation with a hover card
      const { url, siteInfo } = sources[Number(text) + 1];
      if (!siteInfo) {
        el.remove();
        return;
      }

      const sourceNode = document.createElement('span');
      sourceNode.className = 'inline-citation';
      sourceNode.innerHTML = `
      <sup>
        <a href="${url}" target="_blank">
          [${text}]
        </a>
      </sup>
      <span class="source-hover">
        <span class="source-card">
          <span class="source-header">
            <span class="source-publisher">${siteInfo.publisher}</span>
            ${siteInfo.datePublished ? `<span class="source-date">${siteInfo.datePublished}</span>` : ''}
          </span>
          <a class="source-title" href="${url}" target="_blank">
            ${siteInfo.title}
          </a>
          <span class="source-description">${siteInfo.description}</span>
          <span class="source-type">
            ${siteInfo.type}
          </span>
        </span>
      </span>`;

      el.replaceWith(sourceNode);
    } catch (err) {
      el.remove();
    }
  });

  return {
    html: doc.body.innerHTML,
    toc,
  };
};
